namespace ResourceManageGroup.Models;
public class WebApi
{
    public int EmployeeId { get; set; }
    public string? EmployeeName { get; set; }
    public double EmployeeSalary { get; set; }
    public int EmployeeAge { get; set; }
}

